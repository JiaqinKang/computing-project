function EditShape(){
    //set an icon and a name for the object
	this.icon = "assets/editshape.jpg";
	this.name = "editshape";

    var finishedButton;
    var editButton;
    var editMode = false;
    var currentShape = [];

    this.draw = function (){
        //set nofill to avoid shading when drawing shape
        noFill();
        
        //updatePixels to make ensure is not saved during editing and drawing
        updatePixels();
        
        //only if the mouse is pressed in canvas 
        if (mousePressOnCanvas(c) && mouseIsPressed){
            if (!editMode){
                currentShape.push({
                    x:mouseX,
                    y:mouseY
                });
            }
            else {
                for (var i = 0 ; i < currentShape.length; i ++){
                    if (dist(currentShape[i].x,
                            currentShape[i].y,
                            mouseX,
                            mouseY) <15 ){
                        currentShape[i].x = mouseX;
                        currentShape[i].y = mouseY;
                        
                    }
                }	
            }
        }
        
        beginShape();
        for (var i =0; i < currentShape.length;i++){
            vertex(currentShape[i].x,
                   currentShape[i].y);
            
            //add elipse to show vertices
            if (editMode){
                fill('red');
                ellipse (currentShape[i].x,
                        currentShape[i].y,
                        10);
                //set nofill to avoid shading bug
                noFill();
            }

        }
        endShape();



    };



// function to create button options and switch mode between edit shape and add vertices
    this.populateOptions = function() {
        // create button
		select(".options").html(
			"<button id='directionButton'>Edit</button>");
		//click handler
        select("#directionButton").mouseClicked(function() {
			editButton = select("#" + this.elt.id);
			
            if (editMode){
                editMode =false;
                editButton.html("Edit Shape");
            }
            else {
                editMode = true;
                editButton.html("Add Vertices");
            }
		});
	};


    this.unselectTool = function() {
		//clear options
		select(".options").html("");
        
        //stop editmode
        editMode =false;

        //save drawing 
        loadPixels();
        //clear currentshape array 
        currentShape = [];
	};



}