function Eraser(){
	//set an icon and a name for the object
	this.icon = "assets/eraser.jpg";
	this.name = "eraser";

	var eraseMode;

	var eraserErasing = true;

	this.draw = function(){

			//mouse pressed to erase the area
			if (mouseIsPressed && eraserErasing == true) {
                //save to canvas
                loadPixels();
                //clear area
                this.eraserArea();

		  	}else {//else show eraser position
                updatePixels();
				this.drawEraser();
			}
    }
    

	//show eraser area at mouse position X,Y
	this.drawEraser = function(){
		//set nofill to be able to see through 
		//the area and see what is going to be cleared
		noFill();

		//set stroke colour to locate area of the ellipse to be erased
		stroke('black');
		
		//draw the ellipse at mouseX,Y with size 50
		ellipse(mouseX,mouseY,50);
	}
    
    
    //erase area
    
    this.eraserArea = function (){
        //draw a white filled ellipse and save to the canvas
                //set colour
                fill('255');

    			//set ellipse with no stroke
    			noStroke();

                //draw the ellipse at mouseX,Y and +2 for the size 
                //(to counter show ellipse stoke weights)
                ellipse(mouseX,mouseY,52);

    }

	//create buttons
	this.populateOptions = function() {
		select(".options").html(
			"<button id='directionButton'>Ellipse</button>");

		//click handler
		select("#directionButton").mouseClicked(function() {
			eraseButton = select("#" + this.elt.id);

			if (editMode){
                eraseMode = false;
                eraseButton.html("Ellipse");
            }
            
            //need to do
            //additional function to use square eraser
//            else {
//                eraseMode = true;
//                eraseButton.html("Square");
//            }
		});
	};
    
    
    //select tool function to set to true
    this.selectTool = function (){
        eraserErasing = true;
    }
    
    
    //unselect tool and set vars back to original condition for debug 
	this.unselectTool = function() {
		//clear options
		select(".options").html("");
        //setting vars back to original condition
		eraserErasing = false;
        eraseMode = false;
        
        //set fill and stroke to default black colour
        fill('black');
        stroke('black');
	};
    
    
    /// todo adding a pop up to tell the user how to use this tool
    //for better user experience 
    //example code:
    //window.alert("Hello world!");
    //alert("Hello world!");



}